package hn.edu.ujcv.pdm_2021_iii_p1_proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_guardar_producto.*
import java.lang.StringBuilder

class GuardarProductoActivity : AppCompatActivity() {
   var productos : HashMap<Int, String> = hashMapOf()
    var numeroProductos=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guardar_producto)
        btn_guardarProducto.setOnClickListener{ guardarProductos()}
    }



    private fun guardarProductos(){
        val guardar_productos = Intent(this, MainActivity::class.java )
        guardar_productos.putExtra("productos", productos)
        guardar_productos.putExtra("preciopro",txtPrecioProducto.text.toString())
        val datoP = StringBuilder()
        numeroProductos=+1
        datoP.append(txtCodigoProducto.text.toString().trim()).append("|")
        datoP.append(txtNombreProducto.text.toString()).append("|")
        datoP.append(txtProveedorProducto.text.toString()).append("|")
        datoP.append(txtPrecioProducto.text.toString()).append("|")
        datoP.append(txtStockActualProducto.text.toString())
        productos.put(numeroProductos,datoP.toString())
        startActivity(guardar_productos)
    }
}