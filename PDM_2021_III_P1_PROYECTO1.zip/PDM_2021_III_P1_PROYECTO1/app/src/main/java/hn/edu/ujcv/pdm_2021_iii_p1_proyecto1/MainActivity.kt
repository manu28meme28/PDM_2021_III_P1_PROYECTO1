package hn.edu.ujcv.pdm_2021_iii_p1_proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_guardar_producto.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn_Productos.setOnClickListener{ingresarProducto()}
        btn_Clientes.setOnClickListener{ingresarCliente()}
        btn_Facturas.setOnClickListener{ingresarFactura()}
        btn_buscarProducto.setOnClickListener{buscarProducto()}

    }
    private fun ingresarProducto(){
        val ingresar_producto = Intent(this,GuardarProductoActivity::class.java )
        startActivity(ingresar_producto)
}
    private fun ingresarCliente(){
        val ingresar_cliente = Intent(this,GuardarClienteActivity::class.java )
        startActivity(ingresar_cliente)
    }
    private fun ingresarFactura(){
        val ingresar_factura = Intent(this,GuardarFacturaActivity::class.java )
        startActivity(ingresar_factura)
    }
    private fun buscarProducto(){
        val buscar_producto = Intent(this,BuscarProductoActivity::class.java )
        startActivity(buscar_producto)
    }

    }
