package hn.edu.ujcv.pdm_2021_iii_p1_proyecto1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_mostrar_producto.*

class MostrarProductoActivity : AppCompatActivity() {
    var productos: HashMap<Int, String> = hashMapOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mostrar_producto)
        MostrarProducto()
    }

    private fun MostrarProducto() {
        var intent = intent
        var codigo=""
        var nombre =""
        var proveedor=""
        var precio=""
        var stock=""
        productos = intent.getSerializableExtra("productos") as HashMap<Int, String>
        for (producto in productos) {
            val listP = productos.toString().split("|").toTypedArray()
            codigo = listP[0]
            nombre= listP[1]
            proveedor= listP[2]
            precio= listP[3]
            stock= listP[4]
        }
        txvCodigo.text = codigo
        txvNombre.text= nombre
        txvProveedor.text= proveedor
        txvPrecio.text=precio
        txvStock.text=stock


    }
}