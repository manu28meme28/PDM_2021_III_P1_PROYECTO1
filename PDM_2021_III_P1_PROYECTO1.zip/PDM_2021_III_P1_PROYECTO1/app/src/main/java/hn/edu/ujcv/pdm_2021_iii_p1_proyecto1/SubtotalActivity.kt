package hn.edu.ujcv.pdm_2021_iii_p1_proyecto1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_subtotal.*

class SubtotalActivity : AppCompatActivity() {
    var pro: HashMap<Int, String> = hashMapOf()
    var fac: HashMap<Int, String> = hashMapOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subtotal)
        getSubtotal()
    }

    private fun getSubtotal() {
        var intent = intent
        fac = intent.getSerializableExtra("Facturas") as HashMap<Int, String>
        pro = intent.getSerializableExtra("productos") as HashMap<Int, String>
        var precio = 0
        var total = 0.0
        var cantidad = 0
        for (factura in fac) {
            val listF = factura.toString().split("|").toTypedArray()
            cantidad = listF[4].toString().toInt()

            for (producto in pro) {
                val listp = producto.toString().split("|").toTypedArray()
                precio = listF[3].toString().toInt()

            }
            total = (precio * cantidad).toDouble()
            txtvSubtotal2.setText(total.toString())
        }
    }
}
