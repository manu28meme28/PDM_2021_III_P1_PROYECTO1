package hn.edu.ujcv.pdm_2021_iii_p1_proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_buscar_producto.*

class BuscarProductoActivity : AppCompatActivity() {
    var productos: HashMap<Int, String> = hashMapOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buscar_producto)
        btnEnviarP.setOnClickListener { enviarP () }
    }

    private fun enviarP() {
        val intent = Intent(this, MostrarProductoActivity::class.java)
        intent.putExtra("productos", productos)
        startActivity(intent)
    }
}
