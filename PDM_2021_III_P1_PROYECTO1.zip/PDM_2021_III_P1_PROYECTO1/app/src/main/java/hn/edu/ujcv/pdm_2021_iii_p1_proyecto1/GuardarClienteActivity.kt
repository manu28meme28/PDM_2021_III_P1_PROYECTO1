package hn.edu.ujcv.pdm_2021_iii_p1_proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_guardar_cliente.*
import java.lang.StringBuilder

class GuardarClienteActivity : AppCompatActivity() {
    var clientes: HashMap<Int, String> = hashMapOf()
    var numeroClientes=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guardar_cliente)
        btnGuardarCliente.setOnClickListener{guardarCliente()}
    }


    private fun guardarCliente(){
        val guardar_clientes = Intent(this, MainActivity::class.java )
        guardar_clientes.putExtra("Clientes", clientes)
        val datoC = StringBuilder()
        numeroClientes=+1
        datoC.append(txtidCliente.text.toString().trim()).append("|")
        datoC.append(txtNombreCliente.text.toString()).append("|")
        datoC.append(txtFechaNacimiento.text.toString()).append("|")
        datoC.append(txtFechadeIngreso.text.toString()).append("|")
        datoC.append(txtCorreoCliente.text.toString())
        clientes.put(numeroClientes,datoC.toString())
        startActivity(guardar_clientes)
    }
}