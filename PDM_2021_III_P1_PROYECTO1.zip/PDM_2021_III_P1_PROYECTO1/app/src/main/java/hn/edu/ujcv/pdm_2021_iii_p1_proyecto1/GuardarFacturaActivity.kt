package hn.edu.ujcv.pdm_2021_iii_p1_proyecto1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_guardar_factura.*
import kotlinx.android.synthetic.main.activity_guardar_producto.*
import java.lang.StringBuilder
import android.content.Intent as Intent

class GuardarFacturaActivity : AppCompatActivity() {
    var productos: HashMap<Int, String> = hashMapOf()
    var facturas: HashMap<Int, String> = hashMapOf()
    var numeroFacturas = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guardar_factura)
        btnGuardarFactura.setOnClickListener { guardarFactura() }
        btnCalcularSubtotal.setOnClickListener({subtotal()})
    }



    private fun subtotal() {
        val intent = Intent(this,SubtotalActivity ::class.java)
        intent.putExtra("preciopro", txtPrecioProducto.text.toString())
        intent.putExtra("cantidad",txtCantidad.text.toString())
        startActivity(intent)

    }


    private fun guardarFactura() {
        val guardar_facturas = Intent(this, MainActivity::class.java)
        guardar_facturas.putExtra("Facturas", facturas)
        guardar_facturas.putExtra("cantidad", txtCantidad.text.toString())
        val datoF = StringBuilder()

        numeroFacturas = +1
        datoF.append(txtidFactura.text.toString().trim()).append("|")
        datoF.append(txtFechaFactura.text.toString()).append("|")
        datoF.append(txtIdClienteFactura.text.toString()).append("|")
        datoF.append(txtCodigoProFactura.text.toString()).append("|")
        datoF.append(txtCantidad.text.toString()).append("|")
        datoF.append(txtvSubtotalFinal.text.toString())
        facturas.put(numeroFacturas, datoF.toString())
        startActivity(guardar_facturas)
    }
}






